/**
 * 
 */
package com.mycom.EmployeeManager.graphQl.queries;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.coxautodev.graphql.tools.GraphQLQueryResolver;
import com.mycom.EmployeeManager.dto.employee.EmployeeDTO;
import com.mycom.EmployeeManager.services.EmployeeService;

/**
 * @author 1028654
 *
 */
@Component
public class EmployeeQuery implements GraphQLQueryResolver {

	public String firstQuery() {
		return "firstQuery";
	}
	
	public String secondQuery() {
		return "secondQuery";
	}
	
	public EmployeeDTO getEmployee() {
		return new EmployeeDTO("Chiranjit", 123L, 2333.00);
	}
	
	public String fullName(String fName,String lName) {
		
		return fName+" "+lName;
		
	}
	
	@Autowired
	EmployeeService empser;
	
	public EmployeeDTO getEmployeeId(Long id) {
		EmployeeDTO dto= empser.getEmployeeById(id);
		System.out.println(dto);
		return dto;
	}
	public List<EmployeeDTO> getAllEmployee() {
		return empser.getAllEmployees();
	}
	
	
}
