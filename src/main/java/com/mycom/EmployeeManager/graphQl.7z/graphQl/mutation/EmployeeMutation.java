/**
 * 
 */
package com.mycom.EmployeeManager.graphQl.mutation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.coxautodev.graphql.tools.GraphQLMutationResolver;
import com.mycom.EmployeeManager.Exception.BusinessException;
import com.mycom.EmployeeManager.dto.employee.EmployeeDTO;
import com.mycom.EmployeeManager.dto.enums.ResponseCodeEnum;
import com.mycom.EmployeeManager.dto.response.EmployeeServiceResponse;
import com.mycom.EmployeeManager.services.EmployeeService;

/**
 * @author 1028654
 *
 */
@Service
public class EmployeeMutation implements GraphQLMutationResolver {

	@Autowired
	EmployeeService empser;
	
	public EmployeeDTO createEmployee(EmployeeDTO employee)
			throws BusinessException {
		return empser.createemployee(employee);

		
	}

}
