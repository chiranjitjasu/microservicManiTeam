/**
 * 
 */
/**
 * @author 1028654
 *
 */
package com.mycom.EmployeeManager.graphQl;